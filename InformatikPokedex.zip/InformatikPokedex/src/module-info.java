/**
 * 
 */
/**
 * @author v.peters
 *
 */
module InformatikPokedex {
}