package Info;

//Hauptklasse des Codes, enth�lt die main classe
public class Main {			
	public static POKEDEX Dex;
	public static Pokemon POk;
	public static NODE node;
	public static saving Save;
	public static UserInterface UI;


	//main Klasse, wird automatisch bei Code Start ausgef�rth und Strted alle Funktionen
	public static void main(String[] args) {
		POk = new Pokemon (1, "Bulbasaur", 45, 49, 49, 65, 65, 45, 3, 7, true); //creates the first Pokemon
		node = new NODE (null, POk);	//creates the first nod with Bulbasaur and null as next
		Dex = new POKEDEX(node);	//creates the POkedex, containing the nodes 
		Save = new saving(Dex);		//creates a instance of Saving to load the POkemon in the Pokedex
		saving.read();				//starts the instance of Saving
		//Dex.printAll();			//test to see if all POkemon have been loaded korectly			
		UI = new UserInterface(Dex);	//starts the UI (User Interface)
	}

}
